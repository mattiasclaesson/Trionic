﻿/*
 * The ADO.NET SQL provider for Transbase (tb.net20.dll) is installed with
 * the ADO.NET package and must be available via the project dependencies.
 */
using System;
using System.Data.Common;
using System.Data;

using Transaction.Transbase;

namespace ConsoleApplication
{
    class Program
    {
        private static DataSet set = new DataSet();

      private static void DisplayData(System.Data.DataTable table)
      {
         foreach (System.Data.DataRow row in table.Rows)
         {
            foreach (System.Data.DataColumn col in table.Columns)
            {
               Console.WriteLine("{0} = {1}", col.ColumnName, row[col]);
            }
         Console.WriteLine("============================");
         }
      }

      private static void ShowTable(DataTable table)
      {
          foreach (DataColumn col in table.Columns)
          {
              Console.Write("{0,-14}", col.ColumnName);
          }
          Console.WriteLine();

          foreach (DataRow row in table.Rows)
          {
              foreach (DataColumn col in table.Columns)
              {
                  if (col.DataType.Equals(typeof(DateTime)))
                      Console.Write("{0,-14:d}", row[col]);
                  else if (col.DataType.Equals(typeof(Decimal)))
                      Console.Write("{0,-14:C}", row[col]);
                  else
                      Console.Write("{0,-14}", row[col]);
              }
              Console.WriteLine();
          }
          Console.WriteLine();
      }


      private static void GetDataSetSpsHwdescription(TbConnection con, string command)
      {
          DbCommand com = con.CreateCommand();
          com.CommandText = command;

          DataTable table = new DataTable("sps_hwdescription");
          DataColumn workCol = table.Columns.Add("hwid", typeof(Int32));
          workCol.AllowDBNull = false;
          workCol.Unique = true;

          table.Columns.Add("hwlocid", typeof(Int32));
          table.Columns.Add("hwname", typeof(String));

          table.Load(com.ExecuteReader());
          set.Tables.Add(table);

          workCol.Dispose();
          com.Dispose();
      }

      private static void GetDataSetSpsSchema(TbConnection con, string command)
      {
          DbCommand com = con.CreateCommand();
          com.CommandText = command;

          DataTable table = new DataTable("sps_schema");

          DataColumn workCol = table.Columns.Add("schemaid", typeof(Int32));
          workCol.AllowDBNull = false;
          workCol.Unique = true;

          table.Columns.Add("wmi", typeof(String));
          table.Columns.Add("salesmakecode", typeof(Int32));
          table.Columns.Add("protocol", typeof(Int32));
          table.Columns.Add("systemtype", typeof(Int32));
          table.Columns.Add("modelyearcode", typeof(Int32));
          table.Columns.Add("vinpattern", typeof(String));
          table.Columns.Add("snfrom", typeof(String));
          table.Columns.Add("snto", typeof(String));
          table.Columns.Add("hwid", typeof(Int32));
          table.Columns.Add("identtype", typeof(Int32));

          table.Load(com.ExecuteReader());
          set.Tables.Add(table);

          workCol.Dispose();
          com.Dispose();
      }


      static void Main(string[] args)
        {
            try
            {
                TbConnection con = new TbConnection("t2w_spssbdb:5024", "tbadmin", "dgs");
                
                con.Open();

                //----- getschema
                {
                    System.Data.DataTable dt = con.GetSchema("Tables");
                    DisplayData(dt);
                }
                //--------------------------

                //----- SPS_VERSION
                {
                    DbCommand com = con.CreateCommand();
                    com.CommandText = "select item,version from sps_version";
                    DbDataReader dr = com.ExecuteReader();

                    Console.Out.WriteLine(com.CommandText);
                    while (dr.Read())
                    {
                        string tab = dr.GetString(0) + " " + dr.GetString(1);
                        Console.Out.WriteLine(tab);
                    }
                    dr.Close();
                    dr.Dispose();
                    com.Dispose();
                }
                //--------------------------

                Console.Out.WriteLine("Push");
                Console.In.ReadLine();

                //----- SPS_HWDESCRIPTION
                {
                    DbCommand com = con.CreateCommand();
                    com.CommandText = "select hwid,hwlocid,hwname from sps_hwdescription";
                    DbDataReader dr = com.ExecuteReader();

                    Console.Out.WriteLine(com.CommandText);
                    while (dr.Read())
                    {
                        string tab = dr.GetString(0) + " " + dr.GetString(1) + " " + dr.GetString(2);
                        Console.Out.WriteLine(tab);
                    }
                    dr.Close();
                    dr.Dispose();
                    com.Dispose();
                }
                //--------------------------



                Console.Out.WriteLine("Push");
                Console.In.ReadLine();

                //----- SPS_BLOBS
                {
                    DbCommand com = con.CreateCommand();
                    com.CommandText = "select moduleid,moduleblob,blobsize from sps_blobs";
                    DbDataReader dr = com.ExecuteReader();

                    Console.Out.WriteLine(com.CommandText);
                    while (dr.Read())
                    {
                        string tab = dr.GetString(0) + " " + dr.GetString(1) + " " + dr.GetString(2);
                        Console.Out.WriteLine(tab);

                        int size = dr.GetInt32(2);
                        byte[] binary = new byte[dr.GetInt32(2)];
                        dr.GetBytes(1, 0, binary,0,size);
                    }
                    dr.Close();
                    dr.Dispose();
                    com.Dispose();
                }
                //--------------------------

                Console.Out.WriteLine("Push");
                Console.In.ReadLine();

                //----- SPS_SCHEMA
                {
                    DbCommand com = con.CreateCommand();
                    com.CommandText = "select schemaid,wmi,salesmakecode,protocol,systemtype,modelyearcode,vinpattern,snfrom,snto,hwid,identtype from sps_schema";
                    DbDataReader dr = com.ExecuteReader();

                    Console.Out.WriteLine(com.CommandText);
                    while (dr.Read())
                    {
                        string tab = dr.GetString(0) + " " + dr.GetString(1) + " " + dr.GetString(2) + " " + dr.GetString(3) + " " + dr.GetString(4) + " " + dr.GetString(5) + " " + dr.GetString(6) + " " + dr.GetString(7) + " " + dr.GetString(8) + " " + dr.GetString(9) + " " + dr.GetString(10) + " " + dr.GetString(10);
                        Console.Out.WriteLine(tab);
                    }
                    dr.Close();
                    dr.Dispose();
                    com.Dispose();
                }
                //--------------------------

                Console.Out.WriteLine("Push");
                Console.In.ReadLine();

                // Now with DataSet instead
                string command = "select hwid,hwlocid,hwname from sps_hwdescription";
                GetDataSetSpsHwdescription(con, command);
                
                command = "select schemaid,wmi,salesmakecode,protocol,systemtype,modelyearcode,vinpattern,snfrom,snto,hwid,identtype from sps_schema";
                GetDataSetSpsSchema(con, command);
                set.Relations.Add("schema_hwid", set.Tables["sps_hwdescription"].Columns["hwid"], set.Tables["sps_schema"].Columns["hwid"]);

                foreach (DataRow myDataRow1 in set.Tables["sps_schema"].Rows)
                {
                    Console.Write("Schema: " + myDataRow1["schemaid"].ToString() + " " + myDataRow1["hwid"].ToString());

                    // Iterate over hwid data.
                    foreach (DataRow myDataRow2 in myDataRow1.GetChildRows(set.Relations["schema_hwid"]))
                    {
                        Console.Write(" hwid->hwname #" + myDataRow2["hwname"].ToString());
                    }

                    Console.WriteLine();
                }


                //
                set.Dispose();
                con.Close();
                con.Dispose();
            }

            catch (TbException tbx)
            {
                Console.Out.WriteLine("ErrorCode: " + tbx.Code);
                Console.Out.WriteLine(tbx.Message);
            }
            Console.Out.WriteLine("Application about to terminate. Press Enter to finish!");
            Console.In.ReadLine();
        }
    }

}
